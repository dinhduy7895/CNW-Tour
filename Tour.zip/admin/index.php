<?php 
    
    require_once './layout/header.php';
    require_once './layout/left.php';
   

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content main-page">
        <div class="row">
            <h1 class="welcome">
                WELCOME TO MY PAGE
            </h1>
            <p class="welcome-main">
                This is a page for manager Tour like </br>
                CREATE SEARCH VIEW DELETE UPDATE 
            </p>
        </div>

    </section>
    <!-- /.content -->
  </div>
<?php
    require_once './layout/footer.php';
?>